package exam.abstractfactory;

import exam.sourcing.QuestionSource;

public interface QuestionFactory {
    Question createQuestion();
    QuestionRenderer createRenderer();
    QuestionEvaluator createEvaluator();
}
